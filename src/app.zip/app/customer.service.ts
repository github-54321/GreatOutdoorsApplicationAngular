import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { identifierModuleUrl } from '@angular/compiler';
import { Customer } from './Customer';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class CustomerService {
  private baseUrl = 'http://localhost:8082/api/v1';

  constructor(private http: HttpClient) {}

  getCustomers(): Observable<any> {
    return this.http
      .get(`${this.baseUrl}/getallcustomers`)
      .pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      console.error('Client Side Error: ', error.error.message);
    } else {
      console.error('Server Side Error: ', error);
    }
    return throwError('There is problem with Service');
  }

  removeCustomerById(id: number): Observable<any> {
    return this.http
      .delete(`${this.baseUrl}/deletecustomerByCustomerId/` + id)
      .pipe(catchError(this.handleError));
  }

  getCustomerById(id: number): Observable<any> {
    return this.http
      .get(`${this.baseUrl}/viewCustomerbyCustomerId/${id}`)
      .pipe(catchError(this.handleError));
  }

  addCustomer(customer: Customer): Observable<any> {
    return this.http
      .post(`${this.baseUrl}` + `/insertcustomer/`, customer)
      .pipe(catchError(this.handleError));
  }
  editCustomer(customer: Customer): Observable<any> {
    return this.http
      .put(`${this.baseUrl}` + `/updatecustomer/`, customer)
      .pipe(catchError(this.handleError));
  }
  login(email: string, pass: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/logincustomer/${email}/${pass}`);
  }
  getUserById(userId: any): Observable<any> {
    return this.http
      .get(`${this.baseUrl}/viewCustomerbyCustomerId/${userId}`)
      .pipe(catchError(this.handleError));
  }
  loginAdmin(userId: number, pass: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/login/${userId}/${pass}`);
  }

  getAdminById(userId: any): Observable<any> {
    return this.http
      .get(`${this.baseUrl}/viewuserbyid/${userId}`)
      .pipe(catchError(this.handleError));
  }

  isLoggedAdmin(): boolean {
    let adminid = sessionStorage.getItem('adminid');
    if (adminid == null || adminid == '') return false;
    else return true;
  }
  isLoggedCustomer(): boolean {
    let email = sessionStorage.getItem('userid');
    if (email == null || email == '') return false;
    else return true;
  }
}
