export class Address {
    addressId: number=0;
    buildingNo!: number;
    streetName: string='';
    area: string='';
    city: string='';
    state: string='';
    zip!: number;
}
