export class Order {

orderId!:number;
customerId!:number;
productQuantity!:number;
productId!:String;	
dispatchDate!:Date;	
deliveryDate!:Date;
}