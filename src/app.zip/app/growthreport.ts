export class Growthreport
{      growthReportId!:number;
		currentdate!:Date;
		revenue!:number;
		amountChange!:number;
		percentageGrowth!:number;
		colorCode!:string;	
    }