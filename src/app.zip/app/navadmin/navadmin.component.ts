import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navadmin',
  templateUrl: './navadmin.component.html',
  styleUrls: ['./navadmin.component.css']
})
export class NavadminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
