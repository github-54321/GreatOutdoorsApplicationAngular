
import { Customer } from "./Customer";
import { Product } from "./Product";

export class Cart{

    productId!:string;
    productQuantity!:number;
    cutomerId!:number;
  




//     cartId!:number;
//     cartTotalPrice!:number;
//     totalQuantity!:number;
//     customer: Customer = new Customer;
//      
//      quantity!:number;
// Cart(){
//     var map = new Map();
// }
     
//     // let Map<Product,number>=new Map<Product, number>
//     // let map = new Map<Product, number>(); 


}