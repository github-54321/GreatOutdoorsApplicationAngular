import { Product } from "./Product";


export class Salesreport
{
    salesReportId : number=0;
    proddetails : Product = new Product();
    quantitySold :  number=0;
    totalSale : number=0;
}