export class User {
    userId!: number;
    userName: string='';
    userType: string='';
    userPassword:string=''
 
}